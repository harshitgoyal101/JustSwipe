from flask import render_template, url_for, flash, redirect, request, Blueprint
from flask_login import login_user, current_user, logout_user, login_required
from JustSwipe import db, bcrypt
from JustSwipe.models import User, Post
from JustSwipe.users.forms import (RegistrationForm, LoginForm, UpdateAccountForm,
                                   RequestResetForm, Follow, ResetPasswordForm, Find_Friend)
from JustSwipe.users.utils import save_picture, send_reset_email

users = Blueprint('users', __name__)







@users.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(food=form.food.data,computer=form.computer.data,motivation=form.motivation.data,health=form.health.data,username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        return redirect(url_for('main.home'))    
    return render_template('register.html', title='Register', form=form)

@users.route("/", methods=['GET', 'POST'])
@users.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('main.home'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html', title='Login', form=form)

@users.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('main.home'))










@users.route("/edit", methods=['GET', 'POST'])
@login_required
def edit():
    form = UpdateAccountForm()
    if form.validate_on_submit():
        if form.picture.data:
            picture_file = save_picture(form.picture.data)
            current_user.image_file = picture_file
        current_user.username = form.username.data
        current_user.email = form.email.data
        current_user.food = form.food.data
        current_user.motivation = form.motivation.data
        current_user.health= form.health.data
        current_user.computer = form.computer.data
        db.session.commit()
        flash('Your account has been updated!', 'success')
        return redirect(url_for('users.user_profile',username=current_user.username))
    elif request.method == 'GET':
        form.username.data = current_user.username
        form.email.data = current_user.email
        form.food.data = current_user.food
        form.motivation.data = current_user.motivation
        form.computer.data = current_user.computer
        form.health.data = current_user.health
    image_file = url_for('static', filename='profile_pics/' + current_user.image_file)
    return render_template('edit.html', title='Account',
                           image_file=image_file, form=form)

@users.route("/user_friends")
@login_required
def user_friends():
    user = User.query.filter_by(username=current_user.username).first_or_404()
    friends = []
    for u in User.query.all():
        if current_user.is_following(u):
            friends.append(u)
    return render_template('user_friends.html', friends=friends)






















@users.route("/user_profile/<string:username>")
@login_required
def user_profile(username):
    page = request.args.get('page', 1, type=int)
    user = User.query.filter_by(username=username).first_or_404()
    image_file = url_for('static', filename='profile_pics/' + user.image_file)
    form2 = Follow()
    posts = Post.query.filter_by(author=user)\
        .order_by(Post.date_posted.desc())\
        .paginate(page=page, per_page=5)
    return render_template('user_profile.html', posts=posts, user=user, form2=form2,image_file=image_file)

@users.route("/find_friend", methods=['GET', 'POST'])
@login_required
def find_friend():
    form = Find_Friend()
    if form.validate_on_submit():
        page = request.args.get('page', 1, type=int)
        user = User.query.filter(User.email.ilike(form.email.data)).first()
        if user:
            user = user
        else:
            user = User.query.filter(User.username.ilike(form.email.data)).first()
        image_file = url_for('static', filename='profile_pics/' + user.image_file)
        form2 = Follow()
        posts = Post.query.filter_by(author=user)\
            .order_by(Post.date_posted.desc())\
            .paginate(page=page, per_page=5)
        return render_template('user_profile.html', posts=posts, user=user, form2=form2,image_file=image_file)  
    return render_template('find_friend.html', title='Find Friend', form=form)






























@users.route("/reset_password", methods=['GET', 'POST'])
@login_required
def reset_request():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))
    form = RequestResetForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        send_reset_email(user)
        flash('An email has been sent with instructions to reset your password.', 'info')
        return redirect(url_for('users.login'))
    return render_template('reset_request.html', title='Reset Password', form=form)

@users.route("/reset_password/<token>", methods=['GET', 'POST'])
def reset_token(token):
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))
    user = User.verify_reset_token(token)
    if user is None:
        flash('That is an invalid or expired token', 'warning')
        return redirect(url_for('users.reset_request'))
    form = ResetPasswordForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user.password = hashed_password
        db.session.commit()
        flash('Your password has been updated! You are now able to log in', 'success')
        return redirect(url_for('users.login'))
    return render_template('reset_token.html', title='Reset Password', form=form)






















@users.route('/follow/<username>', methods=['POST'])
@login_required
def follow(username):
    form = Follow()
    if form.validate_on_submit():
        user = User.query.filter_by(username=username).first()
        if user is None:
            flash('User {} not found.'.format(username))
            return redirect(url_for('main.home'))
        if user == current_user:
            flash('You cannot follow yourself!')
            page = request.args.get('page', 1, type=int)
            image_file = url_for('static', filename='profile_pics/' + user.image_file)
            form2 = Follow()
            posts = Post.query.filter_by(author=user)\
                .order_by(Post.date_posted.desc())\
                .paginate(page=page, per_page=5)
            return render_template('user_profile.html', posts=posts, user=user, form2=form2,image_file=image_file)

        current_user.follow(user)
        db.session.commit()
        flash('You are following {}!'.format(username))
        page = request.args.get('page', 1, type=int)
        image_file = url_for('static', filename='profile_pics/' + user.image_file)
        form2 = Follow()
        posts = Post.query.filter_by(author=user)\
            .order_by(Post.date_posted.desc())\
            .paginate(page=page, per_page=5)
        return render_template('user_profile.html', posts=posts, user=user, form2=form2,image_file=image_file)
    else:
        return redirect(url_for('main.home'))

@users.route('/unfollow/<username>', methods=['POST'])
@login_required
def unfollow(username):
    form = Follow()
    if form.validate_on_submit():
        user = User.query.filter_by(username=username).first()
        if user is None:
            flash('User {} not found.'.format(username))
            return redirect(url_for('main.home'))
        if user == current_user:
            flash('You cannot unfollow yourself!')
            page = request.args.get('page', 1, type=int)
            image_file = url_for('static', filename='profile_pics/' + user.image_file)
            form2 = Follow()
            posts = Post.query.filter_by(author=user)\
                .order_by(Post.date_posted.desc())\
                .paginate(page=page, per_page=5)
            return render_template('user_profile.html', posts=posts, user=user, form2=form2,image_file=image_file)

        current_user.unfollow(user)
        db.session.commit()
        flash('You are not following {}.'.format(username))
        page = request.args.get('page', 1, type=int)
        image_file = url_for('static', filename='profile_pics/' + user.image_file)
        form2 = Follow()
        posts = Post.query.filter_by(author=user)\
            .order_by(Post.date_posted.desc())\
            .paginate(page=page, per_page=5)
        return render_template('user_profile.html', posts=posts, user=user, form2=form2,image_file=image_file)
    else:
        return redirect(url_for('main.home'))
