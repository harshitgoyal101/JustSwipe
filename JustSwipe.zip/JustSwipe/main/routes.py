from flask import render_template, request, Blueprint
from sqlalchemy import and_ ,or_
from JustSwipe.models import Post ,User
from flask_login import login_required, current_user
from JustSwipe.posts.forms import SortBy

main = Blueprint('main', __name__)


@main.route("/explore", methods=['GET', 'POST'])
@login_required
def explore():
    form = SortBy()
    interest = []

    page = request.args.get('page', 1, type=int)
    if form.validate_on_submit() and form.category.data!='All':
        posts = Post.query.filter(Post.category==form.category.data).order_by(Post.date_posted.desc()).paginate(page=page, per_page=5)
    else:
        posts = Post.query.order_by(Post.date_posted.desc()).paginate(page=page, per_page=5)
    return render_template('explore.html', posts=posts,form=form)

@main.route("/home", methods=['GET', 'POST'])
@login_required
def home():
    form = SortBy()

    friends = []
    for u in User.query.all():
        if current_user.is_following(u):
            friends.append(u)

    temp = []
    for post in Post.query.all():
        userTN = post.author.username
        userT = User.query.filter_by(username=userTN).first()
        if current_user.is_following(userT) or current_user==userT:
            temp.append(post.id)

    interest = []
    if current_user.food:
        interest.append('Food')
    if current_user.motivation:
        interest.append('Motivation')
    if current_user.health:
        interest.append('Health')
    if current_user.computer:
        interest.append('Computer')
	
    page = request.args.get('page', 1, type=int)
    if form.validate_on_submit() and form.category.data!='All':
        posts = Post.query.filter(and_((Post.category==form.category.data),(Post.id.in_(temp)))).order_by(Post.date_posted.desc()).paginate(page=page, per_page=5)
    else:
        posts = Post.query.filter(and_(Post.category.in_(interest),Post.id.in_(temp))).order_by(Post.date_posted.desc()).paginate(page=page, per_page=5)
    return render_template('home.html', posts=posts,form=form,temp=temp)

@main.route("/about")
@login_required
def about():
    return render_template('about.html', title='About')

@main.route("/dev")
def dev():
    return render_template('dev.html', users=User.query.all())