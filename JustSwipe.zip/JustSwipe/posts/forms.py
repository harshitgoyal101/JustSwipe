from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, SelectField
from wtforms.validators import DataRequired

class PostForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    choices =['Food','Health','Computer','Motivation']
    category = SelectField('Category', validators=[DataRequired()], validate_choice=False,choices=choices)
    content = TextAreaField('Content', validators=[DataRequired()])
    submit = SubmitField('Post')

class SortBy(FlaskForm):
	choices =['All','Food','Health','Computer','Motivation']
	category = SelectField('Category', validators=[DataRequired()], validate_choice=False,choices=choices)
	submit = SubmitField('Sort')